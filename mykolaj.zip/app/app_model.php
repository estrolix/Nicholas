<?php

/**
 * @author Estrolix
 * @copyright 2011
 */
 
class AppModel extends Model {

    var $actsAs = array('Containable');
    
    var $recursive = -1;

}
