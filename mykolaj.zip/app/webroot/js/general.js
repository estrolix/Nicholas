$(function(){
    
    $('#ChildAddForm').bind('submit', findSimilarChildrenFunc);
    
    $('.childDeleteLink').click(function(){
       $('#childDeleteSelectReasonBox').insertAfter($(this).parents('tr:first')).hide().show('fast');
       return false; 
    });
    
    $('.childDeleteLinkInDiv').click(function(){
        if($(this).hasClass('delete_totally')) {
            return confirm('Ви дійсно хочете видалити цю дитину зі списку ?');
        }
        
       $('#childDeleteSelectReasonBox').slideDown('fast');
       return false; 
    });
    
});

var findSimilarChildrenFunc = function findSimilarChildren()
{
    var data = $('#ChildAddForm').serializeArray();
    
    $('#similarChildrenInsertPlace').html('');
    $('#submit_div').hide();
    
    $('#similarChildrenBox').fadeIn();
    $('#similarChildrenLoader').fadeIn();
    
    $('#ChildAddForm').unbind('submit', findSimilarChildrenFunc);
    
    $.post('/children/findSimilar', data, function(response){
        
        if(response == 'success') {
            $('#ChildAddForm').submit();
            return;
        }
        
        $('#similarChildrenLoader').fadeOut(function(){            
            $('#similarChildrenInsertPlace').html(response);
            $('#submit_div').show();                
        });
        
    });
    
    return false;
}

function backToChildrenList()
{
    if(confirm('Ви дійсно бажаєте повернутися назад? Введені дані будуть втрачені.')){
        location.href = '/children';
    }
}

function cancelChildDeleting()
{
    $('#childDeleteSelectReasonBox').hide('fast', function(){
        $(this).find('select').val('1');
    });
}

function deleteChild(button)
{
    var blockForDeleting = $(button).parents('tr:first').prev('tr'); 
    var url = blockForDeleting.find('a.childDeleteLink').attr('href') + '/' + $('#delete_reason_id').val();
    
    //hide deleting reason row
    $('#childDeleteSelectReasonBox').hide('fast', function(){
        $(this).find('select').val('1');
    });
    
    blockForDeleting.hide('fast');
    
    $.post(url, function(response){
         if(response != 'success') {
            alert('Помилка видалення. Перезавантажте сторінку і спробуйте ще раз.');
            blockForDeleting.show('fast');
         }
    });

}

function deleteChildFromDiv(button)
{
    location.href = $('.childDeleteLinkInDiv:first').attr('href') + '/' + $('#delete_reason_id').val();
}