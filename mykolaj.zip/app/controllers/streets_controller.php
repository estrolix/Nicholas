<?php

class StreetsController extends AppController {

	var $name = 'Streets';

	function index() {
		$this->set('streets', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Неправильний ID вулиці', true), 'flash_error');
			$this->redirect(array('action' => 'index'));
		}
		$this->set('street', $this->Street->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->Street->create();
			if ($this->Street->save($this->data)) {
				$this->Session->setFlash(__('Вулиця успішно додана.', true), 'flash_done');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Помилка збереження. Перевірте правильність введених даних.', true), 'flash_warning');
			}
		}
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Неправильний ID вулиці', true), 'flash_error');
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Street->save($this->data)) {
				$this->Session->setFlash(__('Вулиця успішно збережена', true), 'flash_done');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('Помилка збереження. Перевірте правильність введених даних.', true), 'flash_warning');
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Street->read(null, $id);
		}
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Неправильний ID вулиці', true), 'flash_error');
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Street->delete($id)) {
			$this->Session->setFlash(__('Вулиця видалена.', true), 'flash_done');
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Помилка видалення вулиці. Спробуйте ще раз.', true), 'flash_warning');
		$this->redirect(array('action' => 'index'));
	}
}