<?php
class ReasonsController extends AppController {

	var $name = 'Reasons';

	function index() {
		$this->Reason->recursive = 0;
		$this->set('reasons', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid reason', true), 'flash_error');
			$this->redirect(array('action' => 'index'));
		}
		$this->set('reason', $this->Reason->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->Reason->create();
			if ($this->Reason->save($this->data)) {
				$this->Session->setFlash(__('The reason has been saved', true), 'flash_done');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The reason could not be saved. Please, try again.', true), 'flash_warning');
			}
		}
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid reason', true), 'flash_error');
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->Reason->save($this->data)) {
				$this->Session->setFlash(__('The reason has been saved', true), 'flash_done');
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The reason could not be saved. Please, try again.', true), 'flash_warning');
			}
		}
		if (empty($this->data)) {
			$this->data = $this->Reason->read(null, $id);
		}
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for reason', true), 'flash_error');
			$this->redirect(array('action'=>'index'));
		}
		if ($this->Reason->delete($id)) {
			$this->Session->setFlash(__('Reason deleted', true), 'flash_done');
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('Reason was not deleted', true), 'flash_warning');
		$this->redirect(array('action' => 'index'));
	}
}
?>