<?php
 
class AppController extends Controller {

    var $helpers = array('Html','Form','Session','Javascript');
    
    var $components = array('RequestHandler', 'Session');
    
    var $monthes = array('січень', 'лютий', 'березень', 'квітень', 'травень', 'червень', 'липень', 'серпень', 'вересень', 'жовтень', 'листопад', 'грудень');
    
    function beforeFilter ()
    {  
        $this->layout = 'admin_default';
        
        $this->set('monthes', $this->monthes);
    }
    
    function getCurrentDatetime()
    {
        return date('Y-m-d H:i:s');
    }
    
}